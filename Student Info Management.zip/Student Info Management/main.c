//Amine El Idrissi 93085
//Aymane Bokhamy 96569
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

typedef struct{
  int id;
  char name[20];
  double gpa;
}stud;

int menu(void);
void display(stud arr[], int a);
void search_by_id(stud arr[],int a);
void update(stud arr[],int a);
void range_stud(stud arr[],int a);
void sort(stud arr[],int a);
void t_save(stud arr[],int a );
void b_save(stud arr[], int a );
void display_bin(stud arr[], int a);
void swap1(stud *a, stud *b);
void swap(double *a, double *b);

int main(void) {
  FILE *inp;
  stud arr[10];
  char n1[20];
  int n,ch,i;

  inp =fopen("input.txt","r");
  if(inp == NULL)
    printf("File not found!");

  fgets(n1,20, inp);
  
  
  n = atoi(n1); //this function turns a number from a number in a form of string to a number in a form of integer
  
  for(i=0; i<n; i++){
    fscanf(inp,"%d",&arr[i].id);
    fscanf(inp,"%s",arr[i].name);
    fscanf(inp,"%lf",&arr[i].gpa);
  }
  ch =menu();
 do{  
  switch(ch){
      case 1:
        display(&arr[0],n);
        ch = menu();
        break;
      case 2:
        search_by_id(&arr[0],n);
        ch = menu();
        break;
      case 3:
        update(&arr[0],n);
        ch = menu();
        break;
      case 4:
        range_stud(&arr[0],n);
        ch = menu();
        break;
      case 5:
        sort(&arr[0],n);
        ch = menu();
        break;
      case 6:
        t_save(&arr[0],n);
        ch = menu();
      case 7:
        b_save(&arr[0],n);
        ch = menu();
        break;
      case 8:
        display_bin(&arr[0], n);
        ch = menu();
  }
  }while(ch!=9);
}

int menu(void){
  int choice;
  printf("To display all the students please enter 1. \nTo search and display enter 2. \nTo update student data enter 3. \nTo list the student enter 4. \nTo sort the students enter 5. \nTo save the text file enter 6. \nTo save the binary file enter 7. \nTo save read or display from the binary file enter 8. \nTo exit enter 9.  ");
  scanf("%d", &choice);
  return choice;
}
void display(stud arr[],int a){
  int i;
  for(i=0;i<a;i++){
    printf("The student: \nID: %d \nName: %s\nGPA: %lf\n", arr[i].id, arr[i].name, arr[i].gpa);
  }
  
}

void search_by_id(stud arr[],int a){
  int i_d, i, flag=0;

  printf("please enter an id: ");
  scanf("%d", &i_d);

  for(i=0; i<a; i++){
    if(i_d == arr[i].id){
     
      printf("%d\n",i_d);
      printf("%s\n",arr[i].name);
      printf("%lf\n\n",arr[i].gpa);
      flag = 1;
      break;
    }
    else continue;
} 
  if(flag != 1){
    printf("student not found!");
  }

}

void update(stud arr[],int a){
  int id,choice,new_id,i,flag=0,ch;
  char new_name[20];
  double new_gpa;

  printf("Please enter an ID to update the data: ");
  scanf("%d",&id);

  for(i=0;i<a;i++){
    if(id == arr[i].id){
      flag = 1;
      printf("Enter 1 to change the ID\nEnter 2 to change the name\nEnter 3 to change the GPA\n");
      scanf("%d",&choice);
      switch(choice){
        case 1:{
          printf("Please enter the new ID: ");
          scanf("%d",&new_id);
          arr[i].id = new_id;
          break;
        }
        case 2:{
          printf("Please enter the new name: ");
          scanf("%s",new_name);
          strcpy(arr[i].name,new_name);
          break;
        }
        case 3:{
          printf("Please enter the new GPA: ");
          scanf("%lf",&new_gpa);
          arr[i].gpa = new_gpa;
          break;
        }
      }
     
    }
    else  continue;
    }
    if(flag != 1){
      printf("Please enter a valid ID!");
    }

}

void range_stud(stud arr[],int a){
  double gpa1, gpa2;
  int i;

  printf("please enter a range of GPA: ");
  scanf("%lf %lf", &gpa1, &gpa2);

  if(gpa1 > gpa2){
    swap(&gpa1, &gpa2);
  }

  for(i=0; i<a; i++){
    if(arr[i].gpa >= gpa1 && arr[i].gpa <= gpa2){
        printf("this student is within the range: %d\n", arr[i].id);
    } 
  }
  
}

void swap(double *a, double *b){
  double temp;
temp = *a;
*a = *b;
*b = temp;
}

void sort(stud arr[],int a){
  int i,j,min;

  for(i=0;i<a;i++){
    min = i;
    for(j=i+1;j<a;j++){
      if(arr[j].gpa<arr[min].gpa)
        min = j;
    }
    swap1(&arr[min],&arr[i]);
  }

}

void t_save(stud arr[],int a ){
  FILE *outtxt;
  int i;
  
  outtxt =fopen("output.txt","w");
  
  for(i=0; i<a; i++){   
      fprintf(outtxt,"%d\n", arr[i].id);
      fprintf(outtxt,"%s\n", arr[i].name);
      fprintf(outtxt,"%f\n", arr[i].gpa);
  }
  fclose(outtxt);

}
void b_save(stud arr[],int a ){
  FILE *outbin;
      outbin =fopen("outbin.bin","wb");
      fwrite(&arr[0],sizeof(stud),a,outbin);
      fclose(outbin);

}

void display_bin(stud arr[], int a){
  FILE *outbin;
  int i;
  
  outbin =fopen("output.bin","rb");
  fread(arr,sizeof(stud),a,outbin);
  
    for(i=0; i<a; i++){
        printf("%d\n", arr[i].id);
        printf("%s\n", arr[i].name);
        printf("%f\n", arr[i].gpa);
    }
  fclose(outbin);
   
}

void swap1(stud *a, stud *b){
  stud temp;
  temp = *a;
  *a = *b;
  *b = temp;
}